<div id="sidebar-wrapper">
      <ul class="sidebar-nav">
          <li class="sidebar-login">
            <a href="/shared/facebook_login.php" class="facebook_connect sidebar-link track_event" data-target="" data-ga-category="Marketing Website" data-ga-event="Menu Usage" data-ga-label="Login" data-ajax-track="1">
              <div class="sidebar-icon"><span class="glyphicon glyphicon-user"></span></div>Login
            </a>
          </li>
          <li>
            <a href="#" class="sidebar-link track_event" data-target="features" data-ga-category="Marketing Website" data-ga-event="Menu Usage" data-ga-label="Features" data-ajax-track="1">
              <div class="sidebar-icon"><img src="images/sidebar-icon1.png" alt="Features"></div>Features
            </a>
          </li>
          <li>
            <a href="#" class="sidebar-link track_event" data-target="reviews" data-ga-category="Marketing Website" data-ga-event="Menu Usage" data-ga-label="Reviews" data-ajax-track="1">
              <div class="sidebar-icon"><img src="images/sidebar-icon2.png" alt="Reviews"></div>Reviews
            </a>
          </li>
          <!-- <li>
            <a href="#" class="sidebar-link track_event" data-target="media-links" data-ga-category="Marketing Website" data-ga-event="Menu Usage" data-ga-label="Media" data-ajax-track="1">
              <div class="sidebar-icon"><img src="images/sidebar-icon3.png" alt="In the media"></div>In the media
            </a>
          </li> -->
          <li>
            <a href="/pages/jobs" target="_blank" class="sidebar-link track_event" data-ga-category="Marketing Website" data-ga-event="Menu Usage" data-ga-label="Jobs">
                <div class="sidebar-icon blog"><img src="images/sidebar-icon5.png" alt="Jobs"></div>Jobs
            </a>
          </li>
          <li>
            <a href="#" class="sidebar-link track_event" data-target="about" data-ga-category="Marketing Website" data-ga-event="Menu Usage" data-ga-label="About" data-ajax-track="1">
              <div class="sidebar-icon about"><img src="images/sidebar-icon4.png" alt="About"></div>About
            </a>
          </li> 
      </ul>
</div>